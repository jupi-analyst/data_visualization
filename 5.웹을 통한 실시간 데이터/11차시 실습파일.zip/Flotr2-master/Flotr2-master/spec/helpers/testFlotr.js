var TestFlotr = Flotr.noConflict();
