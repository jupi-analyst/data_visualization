A Pen created at CodePen.io. You can find this one at http://codepen.io/mrev/pen/waKvbw.

 from tutorial http://bost.ocks.org/mike/bar/2/

Forked from [Dzulfikar Adi Putra](http://codepen.io/superpikar/)'s Pen [D3JS Simple JSON SVG barchart vertical](http://codepen.io/superpikar/pen/nwybj/).