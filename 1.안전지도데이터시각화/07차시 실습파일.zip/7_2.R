install.packages('ggmap')
library(ggmap)
setwd("c:/rja")
cctv <- read.csv("��������_cctv.csv",header=T)
head(cctv)

gmap <- get_map('Nowon-gu office',zoom=13,maptype='roadmap')
gomap <- ggmap(gmap)+geom_point(data=cctv, aes(x=cctv$�浵 , y=cctv$���� ),size=2,
                  alpha=.5,color="red")
gomap
